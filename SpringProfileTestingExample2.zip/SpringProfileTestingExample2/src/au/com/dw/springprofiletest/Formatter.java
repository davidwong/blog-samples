/**
 * Copyright (C) 2013 David Wong
 * All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the BSD license.  See the LICENSE file for details.
 */
package au.com.dw.springprofiletest;

/**
 * The interface for the class to be tested.
 * 
 * @author David Wong
 *
 */
public interface Formatter {

	public String format(String name);
}
