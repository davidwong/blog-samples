/**
 * Copyright (C) 2013 David Wong
 * All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the BSD license.  See the LICENSE file for details.
 */
package au.com.dw.springprofiletest;


/**
 * Store expected test results for a test case.
 * 
 * @author David Wong
 *
 */
public interface FormatResults {

	/**
	 * Retrieve the expected result for a test method.
	 * 
	 * @param testMethodName
	 * @return
	 */
	public String getExpectedResult(String testMethodName);
}
