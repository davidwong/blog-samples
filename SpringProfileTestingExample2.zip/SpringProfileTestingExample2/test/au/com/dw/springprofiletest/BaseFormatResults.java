/**
 * Copyright (C) 2013 David Wong
 * All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the BSD license.  See the LICENSE file for details.
 */
package au.com.dw.springprofiletest;

import java.util.HashMap;
import java.util.Map;

/**
 * A wrapper class around a map that stores the expected test results for a test case. The expected result for
 * each test is keyed by the test method name in the map.
 * 
 * Subclass to add the expected results for each test method in a test class.
 * 
 * Note: this is not meant to be a example of best practices for storing test results, just a simple demo for
 * the purposes of this sample code.
 * 
 * @author David Wong
 *
 */
public abstract class BaseFormatResults implements FormatResults {

	private Map<String, String>  results;
	
	public BaseFormatResults() {
		results = new HashMap<String, String>();

		setUpResults();
	}

	/**
	 * Setup the map with the expected results for all the test methods in a test class.
	 * Should be keyed by the test method name,
	 * e.g.
	 *   map.put(testMethodName, expectedResult);
	 *   
	 * There should be no need to add the test class name, as it is expected there should be a
	 * separate result object for each test class.
	 * 
	 */
	protected abstract void setUpResults();
	
	/**
	 * Add the expected result for a test method.
	 * 
	 * @param testMethodName
	 * @param result
	 */
	protected void addResult(String testMethodName, String result)
	{
		results.put(testMethodName, result);
	}
	
	@Override
	public String getExpectedResult(String testMethodName)
	{
		return results.get(testMethodName);
	}

}
