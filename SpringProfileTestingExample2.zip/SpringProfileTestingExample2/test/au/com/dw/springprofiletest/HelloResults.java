/**
 * Copyright (C) 2013 David Wong
 * All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the BSD license.  See the LICENSE file for details.
 */
package au.com.dw.springprofiletest;

/**
 * The expected results for testing when using the Spring profile 'hello'.
 * 
 * @author David Wong
 *
 */
public class HelloResults extends BaseFormatResults {

	@Override
	protected void setUpResults() {
		addResult("testDave", "Hello Dave");
	}

}
