/**
 * Copyright (C) 2013 David Wong
 * All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the BSD license.  See the LICENSE file for details.
 */
package au.com.dw.springprofiletest;

/**
 * A common interface for Spring configuration classes that configure the beans for injecting a LogBuilder into a logging test,
 * and also the results bean that contains the expected logging.
 * 
 * 
 * @author David Wong
 *
 */
public interface LogTestConfiguration {

	public Formatter formatter();
	
	public FormatResults results();

}
