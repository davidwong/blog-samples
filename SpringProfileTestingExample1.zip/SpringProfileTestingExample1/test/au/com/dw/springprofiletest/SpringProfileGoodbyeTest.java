/**
 * Copyright (C) 2013 David Wong
 * All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the BSD license.  See the LICENSE file for details.
 */
package au.com.dw.springprofiletest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={CommonTestConfig.class, GoodByeConfig.class})
@ActiveProfiles("goodbye")
public class SpringProfileGoodbyeTest {

	@Autowired
	private Formatter formatter;
	
	@Autowired
	private String testData;
	
	// test methods
	
	@Test
	public void testDave() {
		String result = formatter.format(testData);
		System.out.println("Result = " + result);
		
		String expected = "Good Bye Dave";
		
		assertEquals(expected, result);
	}
	
	// accessors
	
	protected Formatter getFormatter() {
		return formatter;
	}

	protected void setFormatter(Formatter formatter) {
		this.formatter = formatter;
	}

	public String getTestData() {
		return testData;
	}

	public void setTestData(String testData) {
		this.testData = testData;
	}

}
