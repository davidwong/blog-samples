/**
 * Copyright (C) 2013 David Wong
 * All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the BSD license.  See the LICENSE file for details.
 */
package au.com.dw.springprofiletest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * The Spring Java configuration for beans that are common to all tests.
 * 
 * @author David Wong
 *
 */
@Configuration
public class CommonTestConfig {

	@Autowired
	LogTestConfiguration logTestConfiguration;

	@Bean
	public Formatter formatter()
	{
		return logTestConfiguration.formatter();
	}
	
	@Bean
	public String testData()
	{
		return "Dave";
	}
	
}
